This demo currently working on windows only
Double click on the run.bat file
Please follow the program instructions

IMPORTANT:
PERMISSION ISSUE - Run run.bat with Administrator privileges
